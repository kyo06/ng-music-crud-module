import { ShowAnimationDirective } from './show-animation.directive';

describe('ShowAnimationDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowAnimationDirective();
    expect(directive).toBeTruthy();
  });
});
