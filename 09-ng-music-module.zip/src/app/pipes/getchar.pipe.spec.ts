import { GetcharPipe } from './getchar.pipe';

describe('GetcharPipe', () => {
  it('create an instance', () => {
    const pipe = new GetcharPipe();
    expect(pipe).toBeTruthy();
  });
});
