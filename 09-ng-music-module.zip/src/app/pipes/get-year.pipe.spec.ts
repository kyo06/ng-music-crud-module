import { GetYearPipe } from './get-year.pipe';

describe('GetYearPipe', () => {
  it('create an instance', () => {
    const pipe = new GetYearPipe();
    expect(pipe).toBeTruthy();
  });
});
