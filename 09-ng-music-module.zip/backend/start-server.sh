#!/bin/bash

npx json-server@0 --watch db.json --port 3000